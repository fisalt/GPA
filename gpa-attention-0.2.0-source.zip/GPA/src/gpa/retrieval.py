"""Small mixed synthetic retrieval benchmark; NOT official RULER/BABILong.

Train/test seeds specify independent random records and answers. No example
lookup table is shared between datasets. UUID-style means a random FOUR-token
identifier value here, not a tokenizer-equivalent natural-language UUID task.
"""
from dataclasses import dataclass
import random
import torch
from torch import nn
import torch.nn.functional as F
from .attention import DenseGPA, GPAConfig

TASKS = ("single", "uuid4", "mqar", "overwrite")
VOCAB = 256
PAIR, VAL, END, QUERY, ANSWER = 1, 2, 3, 4, 5


def make_example(rng, length, task, records):
    if task not in TASKS:
        raise ValueError(task)
    nvalue, nkey = (4, 2) if task == "uuid4" else (1, 1)
    keys = []
    while len(keys) < records:
        key = (rng.randrange(16, 32), rng.randrange(32, 48)) if nkey == 2 else (rng.randrange(16, 48),)
        if key not in keys:
            keys.append(key)
    values = {key: tuple(rng.randrange(64, 80) for _ in range(nvalue)) for key in keys}
    record_streams = [[PAIR, *key, VAL, *values[key], END] for key in keys]
    if task == "overwrite":
        key = rng.choice(keys)
        values[key] = (rng.randrange(64, 80),)
        record_streams.append([PAIR, *key, VAL, *values[key], END])
    query_keys = rng.sample(keys, min(3, records)) if task == "mqar" else [rng.choice(keys)]
    # Queries use only keys; the target values are never inserted before the
    # query except at their actual records. MQAR queries are non-repeating.
    query_size = sum(2+len(key)+nvalue for key in query_keys)
    available = length-query_size-sum(map(len, record_streams))
    if available < 0:
        raise ValueError("sequence too short for this record/query budget")
    boundaries = sorted(rng.randrange(available+1) for _ in record_streams)
    noise = [rng.randrange(128, VOCAB) for _ in range(available)]
    stream, last = [], 0
    for cut, record in zip(boundaries, record_streams):
        stream.extend(noise[last:cut])
        stream.extend(record)
        last = cut
    stream.extend(noise[last:])
    labels, groups = [-100]*length, []
    for key in query_keys:
        stream.extend([QUERY, *key, ANSWER])
        positions = []
        for value in values[key]:
            pos = len(stream)-1
            labels[pos] = value  # causal next-token target
            positions.append(pos)
            stream.append(value)
        groups.append(positions)
    assert len(stream) == length
    return stream, labels, groups


def make_batch(seed, batch, length, records, task=None, device="cpu"):
    rng = random.Random(seed)
    examples, labels, metadata = [], [], []
    for _ in range(batch):
        kind = task or rng.choices(TASKS, weights=(.3, .3, .2, .2))[0]
        ids, target, groups = make_example(rng, length, kind, records)
        examples.append(ids)
        labels.append(target)
        metadata.append({"task": kind, "groups": groups})
    return (torch.tensor(examples, device=device), torch.tensor(labels, device=device), metadata)


@dataclass
class RetrievalConfig:
    width: int = 128
    heads: int = 4
    layers: int = 2
    slots: tuple = (16, 16, 16, 16)
    chunk_size: int = 64
    convolution: int = 8
    attention: str = "gpa"
    execution: str = "triton"
    backend: str = "fla"
    read_scale: float = 8.
    beta_init: float = .6
    decay_init: float = .0001
    aligned_query: bool = False


class RetrievalBlock(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        width = cfg.width
        self.norm = nn.LayerNorm(width)
        self.qkv = nn.Linear(width, 3*width, bias=False)
        self.conv = nn.Conv1d(3*width, 3*width, cfg.convolution, groups=3*width, bias=False)
        with torch.no_grad():
            self.conv.weight.normal_(0, .03)
            self.conv.weight[:, 0, -1].add_(1.)
        self.out = nn.Linear(width, width, bias=False)
        self.ffnorm = nn.LayerNorm(width)
        self.ff = nn.Sequential(nn.Linear(width, 2*width), nn.GELU(), nn.Linear(2*width, width))
        if cfg.attention == "gpa":
            self.attention = DenseGPA(GPAConfig(
                heads=cfg.heads, key_dim=width//cfg.heads, value_dim=width//cfg.heads,
                slots=cfg.slots, chunk_size=cfg.chunk_size, backend=cfg.backend,
                execution=cfg.execution, read_scale=cfg.read_scale,
                beta_init=cfg.beta_init, decay_init=cfg.decay_init,
                shared_query_center=cfg.aligned_query))
            if cfg.aligned_query:
                self.reset_aligned_queries()
        elif cfg.attention != "transformer":
            raise ValueError("attention must be gpa or transformer")

    @torch.no_grad()
    def reset_aligned_queries(self):
        for qw, rw in zip(self.attention.query_weight, self.attention.route_weight):
            qw.zero_()  # learned delta, NOT the shared C projection
            m = rw.shape[-1]
            rw.copy_(.02*(torch.eye(m, device=rw.device, dtype=rw.dtype)-1/m)[None])

    def forward(self, x):
        b, t, width = x.shape
        projected = self.qkv(self.norm(x)).transpose(1, 2)
        projected = self.conv(F.pad(projected, (self.cfg.convolution-1, 0))).transpose(1, 2)
        q, k, v = [part.reshape(b, t, self.cfg.heads, width//self.cfg.heads)
                   for part in projected.chunk(3, -1)]
        q, k = F.silu(q), F.silu(k)
        if self.cfg.attention == "gpa":
            o, _ = self.attention(q, k, v)
        else:
            o = F.scaled_dot_product_attention(q.transpose(1, 2), k.transpose(1, 2),
                                               v.transpose(1, 2), is_causal=True).transpose(1, 2)
        x = x+self.out(o.reshape(b, t, width))
        return x+self.ff(self.ffnorm(x))


class RetrievalLM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        if cfg.width % cfg.heads:
            raise ValueError("width must be divisible by heads")
        self.config = cfg
        self.embedding = nn.Embedding(VOCAB, cfg.width)
        self.blocks = nn.ModuleList(RetrievalBlock(cfg) for _ in range(cfg.layers))
        self.norm = nn.LayerNorm(cfg.width)
        self.head = nn.Linear(cfg.width, VOCAB, bias=False)
        self.head.weight = self.embedding.weight
        nn.init.normal_(self.embedding.weight, std=.02)

    def forward(self, ids):
        x = self.embedding(ids)
        for block in self.blocks:
            x = block(x)
        return self.head(self.norm(x))


@torch.no_grad()
def evaluate(model, *, length, records, samples=32, batch=8, seed=900000, free_generate=False):
    model.eval()
    device = next(model.parameters()).device
    amp = device.type == "cuda"
    report = {}
    for task in TASKS:
        correct, total, exact, groups_total, first, first_total = 0, 0, 0, 0, 0, 0
        free_correct = free_total = 0
        for start in range(0, samples, batch):
            size = min(batch, samples-start)
            ids, labels, metadata = make_batch(seed+start, size, length, records, task, device)
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                pred = model(ids).argmax(-1)
            mask = labels != -100
            correct += int(((pred == labels) & mask).sum())
            total += int(mask.sum())
            for i, info in enumerate(metadata):
                for group in info["groups"]:
                    groups_total += 1
                    exact += int((pred[i, group] == labels[i, group]).all())
                    first += int(pred[i, group[0]] == labels[i, group[0]])
                    first_total += 1
            if free_generate and task == "uuid4":
                # UUID has exactly one query per row. Recompute prefixes to
                # avoid claiming an unimplemented LM+shortconv cache adapter.
                position = metadata[0]["groups"][0][0]
                assert all(info["groups"][0][0] == position for info in metadata)
                prefix = ids[:, :position+1]
                generated = []
                for _ in range(4):
                    with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=amp):
                        token = model(prefix)[:, -1].argmax(-1)
                    generated.append(token)
                    prefix = torch.cat((prefix, token[:, None]), 1)
                answer = labels[:, position:position+4]
                free_correct += int((torch.stack(generated, 1) == answer).all(1).sum())
                free_total += size
        report[task] = {"token_accuracy": correct/total, "query_exact_match_teacher_forced": exact/groups_total,
                        "first_answer_accuracy": first/first_total, "queries": groups_total}
        if free_total:
            report[task]["free_generation_exact_match"] = free_correct/free_total
    return report
