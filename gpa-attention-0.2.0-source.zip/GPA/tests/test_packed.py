from dataclasses import replace
import pytest
import torch
from gpa import DenseGPA, GPAConfig
from gpa.state import tensors


@pytest.mark.parametrize("mode", ["gated", "moments", "none", "aligned"])
@pytest.mark.parametrize("levels", [1, 2, 4])
def test_packed_equivalence_and_gradients(mode, levels):
    torch.manual_seed(99)
    torch.set_num_threads(1)
    cfg = GPAConfig(heads=2, key_dim=4, value_dim=3, slots=(3,)*levels,
                     positional_mode="gated" if mode == "aligned" else mode, chunk_size=3,
                     shared_query_center=mode == "aligned")
    reference = DenseGPA(cfg).double()
    packed = DenseGPA(replace(cfg, execution="packed")).double()
    packed.load_state_dict(reference.state_dict())
    xs = [torch.randn(2, 7, 2, d, dtype=torch.double, requires_grad=True) for d in (4, 4, 3)]
    ys = [x.detach().clone().requires_grad_() for x in xs]
    a, sa = reference(*xs)
    b, sb = packed(*ys)
    torch.testing.assert_close(a, b, atol=1e-10, rtol=1e-10)
    for x, y in zip(tensors(sa), tensors(sb)):
        torch.testing.assert_close(x, y, atol=1e-10, rtol=1e-10)
    a.square().sum().backward()
    b.square().sum().backward()
    for x, y in zip(xs, ys):
        torch.testing.assert_close(x.grad, y.grad, atol=1e-9, rtol=1e-9)
    for (name, x), (_, y) in zip(reference.named_parameters(), packed.named_parameters()):
        if x.grad is not None:
            assert y.grad is not None, name
            torch.testing.assert_close(x.grad, y.grad, atol=1e-9, rtol=1e-9, msg=name)
