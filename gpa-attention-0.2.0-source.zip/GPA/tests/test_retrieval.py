import random
from dataclasses import replace
import torch
from gpa.retrieval import make_example, make_batch, TASKS, RetrievalLM, RetrievalConfig


def test_synthetic_shapes_labels_and_independent_seeds():
    for task in TASKS:
        ids, labels, groups = make_example(random.Random(10), 128, task, 4)
        assert len(ids) == len(labels) == 128
        assert all(ids[pos+1] == labels[pos] for group in groups for pos in group)
        assert sum(x != -100 for x in labels) == sum(map(len, groups))
    train, _, _ = make_batch(100, 4, 128, 4)
    test, _, _ = make_batch(900000, 4, 128, 4)
    assert not torch.equal(train, test)


def test_tiny_retrieval_model_causal_and_backward_cpu():
    torch.set_num_threads(1)
    cfg = RetrievalConfig(width=16, heads=2, layers=2, slots=(3, 3), chunk_size=8,
                          backend="torch", execution="packed")
    model = RetrievalLM(cfg)
    ids = torch.randint(0, 256, (1, 16))
    a = model(ids)
    b = model(ids[:, :9])
    torch.testing.assert_close(a[:, :9], b, atol=1e-5, rtol=1e-5)
    a.square().mean().backward()
    assert torch.isfinite(model.embedding.weight.grad).all()
