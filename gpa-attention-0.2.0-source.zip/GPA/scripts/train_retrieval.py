"""Single-GPU mixed synthetic retrieval training and independent evaluation."""
import argparse
from dataclasses import asdict
from pathlib import Path
import json
import time
import torch
import torch.nn.functional as F
from gpa.retrieval import RetrievalConfig, RetrievalLM, make_batch, evaluate


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--attention", choices=["gpa", "transformer"], default="gpa")
    p.add_argument("--steps", type=int, default=400)
    p.add_argument("--batch", type=int, default=8)
    p.add_argument("--length", type=int, default=256)
    p.add_argument("--records", type=int, default=8)
    p.add_argument("--width", type=int, default=128)
    p.add_argument("--heads", type=int, default=4)
    p.add_argument("--layers", type=int, default=2)
    p.add_argument("--slots", default="16,16,16,16")
    p.add_argument("--chunk-size", type=int, default=64)
    p.add_argument("--lr", type=float, default=.002)
    p.add_argument("--read-scale", type=float, default=8.)
    p.add_argument("--seed", type=int, default=400)
    p.add_argument("--output", default="retrieval_run")
    p.add_argument("--resume")
    p.add_argument("--eval-samples", type=int, default=32)
    p.add_argument("--eval-only", action="store_true")
    p.add_argument("--eval-lengths", default="128,256,512")
    p.add_argument("--cuda-graph", action="store_true")
    p.add_argument("--easy-curriculum", action="store_true")
    p.add_argument("--aligned-query", action="store_true")
    args = p.parse_args()
    if args.aligned_query and args.attention != "gpa":
        p.error("--aligned-query is a GPA-only parameterization")
    torch.manual_seed(args.seed)
    torch.set_num_threads(4)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    config = RetrievalConfig(width=args.width, heads=args.heads, layers=args.layers,
                              slots=tuple(map(int, args.slots.split(","))), attention=args.attention,
                              chunk_size=args.chunk_size, read_scale=args.read_scale,
                              aligned_query=args.aligned_query)
    model = RetrievalLM(config).cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=.01, fused=True)
    start_step = 0
    if args.resume:
        data = torch.load(args.resume, map_location="cpu", weights_only=False)
        old_config = asdict(RetrievalConfig(**data["config"]))
        desired = asdict(config)
        convert = old_config != desired
        allowed_conversion = (args.aligned_query and not old_config["aligned_query"] and
                              {k: v for k, v in old_config.items() if k != "aligned_query"} ==
                              {k: v for k, v in desired.items() if k != "aligned_query"})
        if convert and not allowed_conversion:
            raise ValueError("checkpoint config differs outside the explicit aligned-query conversion")
        model.load_state_dict(data["model"])
        if not args.eval_only:
            optimizer.load_state_dict(data["optimizer"])
            for group in optimizer.param_groups:
                group["lr"] = args.lr
        start_step = data["step"]
        if convert:
            for block in model.blocks:
                block.reset_aligned_queries()
                for parameter in (*block.attention.query_weight, *block.attention.route_weight):
                    optimizer.state.pop(parameter, None)
            print("EXPLICIT CONVERSION: W_qs=C^T/query_scale+delta, delta=0; route=.02*(I-1/M); reset corresponding optimizer moments", flush=True)
    params = sum(p.numel() for p in model.parameters())
    training_metadata = {"seed": args.seed, "test_seed": 900000, "batch": args.batch,
                         "max_length": args.length, "max_records": args.records,
                         "lr": args.lr, "start_step": start_step,
                         "target_step": args.steps, "easy_curriculum": args.easy_curriculum,
                         "cuda_graph": args.cuda_graph}
    print(json.dumps({"config": asdict(config), "parameters": params, "train_seed": args.seed,
                      "test_seed": 900000, "mixture": {"single": .3, "uuid4": .3, "mqar": .2, "overwrite": .2},
                      "note": "synthetic structured retrieval, not official RULER"}), flush=True)
    if not args.eval_only:
        model.train()
        begin = time.perf_counter()
        captured, captured_length = None, None

        def loss_fn(ids, labels):
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                logits = model(ids)
                loss = F.cross_entropy(logits.float().flatten(0, 1), labels.flatten())
            return loss, logits

        for step in range(start_step, args.steps):
            length = min(128, args.length) if step < 100 else args.length
            records = min(4, args.records) if step < 100 else args.records
            if args.easy_curriculum:
                phase = step-start_step
                length = min(args.length, 64 if phase < 200 else 128 if phase < 600 else args.length)
                records = min(args.records, 1 if phase < 200 else 2 if phase < 400 else 4 if phase < 600 else args.records)
            ids, labels, _ = make_batch(args.seed*100000+step, args.batch, length, records, device="cuda")
            if args.cuda_graph:
                if captured_length != length:
                    from gpa.training_graph import GradientGraph
                    captured = GradientGraph(model, (ids, labels), loss_fn)
                    captured_length = length
                loss, logits = captured.replay(ids, labels)
            else:
                optimizer.zero_grad(set_to_none=True)
                loss, logits = loss_fn(ids, labels)
                loss.backward()
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.)
            if not torch.isfinite(loss) or not torch.isfinite(norm):
                raise RuntimeError(f"nonfinite training at step {step}")
            optimizer.step()
            if (step+1) % 20 == 0:
                torch.cuda.synchronize()
                mask = labels != -100
                acc = ((logits.argmax(-1) == labels) & mask).sum()/mask.sum()
                print(json.dumps({"step": step+1, "loss": loss.item(), "grad_norm": norm.item(),
                                  "answer_token_acc": acc.item(), "length": length,
                                  "records": records,
                                  "seconds_per_step_recent": (time.perf_counter()-begin)/20}), flush=True)
                begin = time.perf_counter()
            if (step+1) % 100 == 0 or step+1 == args.steps:
                torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                            "step": step+1, "config": asdict(config),
                            "training_metadata": training_metadata}, out/f"checkpoint-{step+1}.pt")
    results = {"config": asdict(config), "steps": max(start_step, args.steps) if not args.eval_only else start_step,
               "parameters": params, "training_metadata": training_metadata, "evaluations": {}}
    for length in map(int, args.eval_lengths.split(",")):
        records = min(4, args.records) if length <= 128 else min(args.records+(length//256-1)*4, 16)
        result = evaluate(model, length=length, records=records, samples=args.eval_samples,
                          batch=args.batch, seed=900000, free_generate=True)
        results["evaluations"][str(length)] = {"records": records, "tasks": result,
                                                  "extrapolation": length > args.length}
        (out/"results.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
        print(json.dumps({"eval_length": length, "records": records, "results": result}), flush=True)


if __name__ == "__main__":
    main()
