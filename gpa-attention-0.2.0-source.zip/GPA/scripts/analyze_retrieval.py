"""Inspect observed-token write rates and dense-R effective rank; no oracle writes."""
import argparse
from pathlib import Path
import json
import torch
from gpa.retrieval import RetrievalConfig, RetrievalLM, make_batch


def main():
    p = argparse.ArgumentParser()
    p.add_argument("checkpoint")
    p.add_argument("--output", default="diagnostics.json")
    p.add_argument("--length", type=int, default=256)
    p.add_argument("--plot", action="store_true")
    args = p.parse_args()
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    data = torch.load(args.checkpoint, map_location="cpu", weights_only=False)
    model = RetrievalLM(RetrievalConfig(**data["config"])).cuda().eval()
    model.load_state_dict(data["model"])
    ids, labels, _ = make_batch(901111, 8, args.length, 8 if args.length >= 256 else 4, device="cuda")
    masks = {"noise": ids >= 128, "values": (ids >= 64) & (ids < 80),
             "keys": (ids >= 16) & (ids < 48), "markers": ids < 16,
             "answer_prediction_positions": labels != -100}
    report, heatmaps = {}, []
    handles = []
    for index, block in enumerate(model.blocks):
        if not hasattr(block, "attention"):
            continue

        def hook(module, inputs, output, index=index):
            q, k, v = inputs
            gi, bi, go, bo = module._gates(k, 0)
            entry = {"inner_beta_by_observed_token_type": {}, "outer_beta_by_observed_token_type": {}}
            for name, mask in masks.items():
                entry["inner_beta_by_observed_token_type"][name] = bi[mask].float().mean().item()
                entry["outer_beta_by_observed_token_type"][name] = bo[mask].float().mean().item()
            state = output[1]
            ranks, dominant = [], []
            for relation in state.relations:
                singular = torch.linalg.svdvals(relation.memory.float())
                mass = singular/singular.sum(-1, keepdim=True).clamp_min(1e-12)
                ranks.append((-torch.sum(mass*mass.clamp_min(1e-12).log(), -1)).exp().mean().item())
                dominant.append(mass[..., 0].mean().item())
            entry["relation_effective_rank_mean"] = sum(ranks)/len(ranks) if ranks else None
            entry["relation_top_singular_mass_mean"] = sum(dominant)/len(dominant) if dominant else None
            entry["count_peak_fraction"] = [
                (s.count.max(-1).values/s.count.sum(-1).clamp_min(1e-12)).mean().item() for s in state.levels]
            report[f"layer_{index}"] = entry
            heatmaps.append([s.memory[0].float().mean(0).cpu().numpy() for s in state.relations])

        handles.append(block.attention.register_forward_hook(hook))
    with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
        pred = model(ids).argmax(-1)
    for h in handles:
        h.remove()
    mask = labels != -100
    report["answer_token_accuracy_on_diagnostic_batch"] = ((pred == labels) & mask).sum().item()/mask.sum().item()
    Path(args.output).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2), flush=True)
    if args.plot and heatmaps:
        try:
            import matplotlib
        except ImportError:
            print("matplotlib not installed; JSON diagnostics saved, optional plot skipped")
            return
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        count = len(model.config.slots)
        fig, axes = plt.subplots(count, count, figsize=(2*count, 2*count), squeeze=False)
        images = iter(heatmaps[-1])
        for i in range(count):
            for j in range(count):
                axes[i, j].set_title(f"R {i}->{j}")
                if i != j:
                    axes[i, j].imshow(next(images), aspect="auto", cmap="viridis")
                axes[i, j].set_xticks([])
                axes[i, j].set_yticks([])
        fig.suptitle("Last block: head-averaged dynamic R after one held-out sequence")
        fig.tight_layout()
        fig.savefig(str(Path(args.output).with_suffix(".png")), dpi=150)


if __name__ == "__main__":
    main()
